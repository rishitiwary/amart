<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Api extends CI_Controller {

   public function __construct()
   {
        Parent::__construct();
        $this->load->database();
        $this->load->model('Basic_operation', 'basic_operation', TRUE);
        
        header('Access-Control-Allow-Origin: *');
        header("Access-Control-Allow-Headers: X-API-KEY, Origin, X-Requested-With, Content-Type, Accept, Access-Control-Request-Method");
        header("Access-Control-Allow-Methods: GET, POST, OPTIONS, PUT, DELETE");
        $method = $_SERVER['REQUEST_METHOD'];
        if($method == "OPTIONS") 
        {
        die();
        }
    }

    
    public function CancelledOrder(){
        $api_url = site_url()."app/updateStatus";
        $form_data = array(
         'user_id'  => $this->input->post('user_id'),
         'message'  => $this->input->post('message'),
         'order_id'  => $this->input->post('order_id'),
         'status'  => $this->input->post('status'),
        );
        $client = curl_init($api_url);
    
        curl_setopt($client, CURLOPT_POST, true);
    
        curl_setopt($client, CURLOPT_POSTFIELDS, $form_data);
    
        curl_setopt($client, CURLOPT_RETURNTRANSFER, true);
    
        $response = curl_exec($client);
    
        curl_close($client);
    
        echo $response;
    }
    
    public function login(){

        $api_url = site_url()."app/login";
        $form_data = array(
            'email'  => $this->input->post('email'),
            'password'   => $this->input->post('password'),
            'fcm_token' =>$this->input->post('fcm_token'),
            'device_id' =>$this->input->post('device_id')
        );
        $client = curl_init($api_url);
    
        curl_setopt($client, CURLOPT_POST, true);
    
        curl_setopt($client, CURLOPT_POSTFIELDS, $form_data);
    
        curl_setopt($client, CURLOPT_RETURNTRANSFER, true);
    
        $response = curl_exec($client);
    
        curl_close($client);
    
        echo $response;
    }

    public function sendOTP(){
        $otp=$this->generateNumericOTP(6);
        $param = array(
            'username' => 'yaldafresh',
            'password' => '3eLsEw1v8x',
            'senderid' => 'YALDAFRESH',
            'text' => $otp.' is your one time password(OTP) for phone verification',
            'type' => 'text',
        );
        $mobile=$this->input->post('mobile');
        $recipients = array($mobile);
        $post = 'to=' . implode(';', $recipients);
        foreach ($param as $key => $val) {
            $post .= '&' . $key . '=' . rawurlencode($val);
        }
        $url = "https://smartsmsgateway.com/api/api_json.php";
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_TIMEOUT, 30);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $post);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array("Connection: close"));
        $result = curl_exec($ch);
        if(curl_errno($ch)) {
            $result = "cURL ERROR: " . curl_errno($ch) . " " . curl_error($ch);
        } else {
            $returnCode = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
            switch($returnCode) {
                case 200 :
                    break;
                default :
                    $result = "HTTP ERROR: " . $returnCode;
            }
        }
        curl_close($ch);
        $this->basic_operation->updateDetails('users',array('verify_otp'=>$otp,'mobile_verified'=>'0'),array('mobile'=>$mobile));
        echo json_encode(array(
                    'error'    => false,
                    'message' => 'OTP Send Successfully'
               )); 
    }
    
    public function verifyOTP(){
        
        
         $api_url = site_url()."app/verifyOTP";
        $form_data = array(
         'mobile'  => $this->input->post('mobile'),
         'otp' => $this->input->post('otp')
        );
        $client = curl_init($api_url);
    
        curl_setopt($client, CURLOPT_POST, true);
    
        curl_setopt($client, CURLOPT_POSTFIELDS, $form_data);
    
        curl_setopt($client, CURLOPT_RETURNTRANSFER, true);
    
        $response = curl_exec($client);
    
        curl_close($client);
    
        echo $response;
         
     
    }
    
    // Function to generate OTP 
    public function generateNumericOTP($n) 
    { 
        $generator = "1357902468"; 
        $otp = ""; 
        for ($i = 1; $i <= $n; $i++) { 
            $otp .= substr($generator, (rand()%(strlen($generator))), 1); 
        } 
      
        $chkOTP = $this->basic_operation->matchedRowCount('users',array('verify_otp ='=>$otp));
        if($chkOTP > 0){
           $this->generateNumericOTP(6); 
        }else{
            return $otp;
        }
        
    }
    public function logout()
    {
    
        $api_url = site_url()."app/logout";
        $form_data = array(
         'user_id'  => $this->input->post('user_id'),
         'device_id' => $this->input->post('device_id')
        );
        $client = curl_init($api_url);
    
        curl_setopt($client, CURLOPT_POST, true);
    
        curl_setopt($client, CURLOPT_POSTFIELDS, $form_data);
    
        curl_setopt($client, CURLOPT_RETURNTRANSFER, true);
    
        $response = curl_exec($client);
    
        curl_close($client);
    
        echo $response;
    }
    
    public function forgot()
    {
    
        $api_url = site_url()."app/forgot";
        $form_data = array(
         'email'  => $this->input->post('email'),
        );
        $client = curl_init($api_url);
    
        curl_setopt($client, CURLOPT_POST, true);
    
        curl_setopt($client, CURLOPT_POSTFIELDS, $form_data);
    
        curl_setopt($client, CURLOPT_RETURNTRANSFER, true);
    
        $response = curl_exec($client);
    
        curl_close($client);
    
        echo $response;
    }


/* *****************************************  Users APIs ****************************************** */

public function UserLogin()
{

    $api_url = site_url()."users/login";
    $form_data = array(
        'email'  => $this->input->post('email'),
        'password'   => $this->input->post('password'),
        'fcm_token' =>$this->input->post('fcm_token')
    );
    $client = curl_init($api_url);

    curl_setopt($client, CURLOPT_POST, true);

    curl_setopt($client, CURLOPT_POSTFIELDS, $form_data);

    curl_setopt($client, CURLOPT_RETURNTRANSFER, true);

    $response = curl_exec($client);

    curl_close($client);

    echo $response;
}
public function UserLogout(){

$api_url = site_url()."users/logout";
$form_data = array(
 'token'  => $this->input->post('token'),
);
$client = curl_init($api_url);

curl_setopt($client, CURLOPT_POST, true);

curl_setopt($client, CURLOPT_POSTFIELDS, $form_data);

curl_setopt($client, CURLOPT_RETURNTRANSFER, true);

$response = curl_exec($client);

curl_close($client);

echo $response;
}

public function UserForgot(){

$api_url = site_url()."users/forgot";
$form_data = array(
 'email'  => $this->input->post('email'),
);
$client = curl_init($api_url);

curl_setopt($client, CURLOPT_POST, true);

curl_setopt($client, CURLOPT_POSTFIELDS, $form_data);

curl_setopt($client, CURLOPT_RETURNTRANSFER, true);

$response = curl_exec($client);

curl_close($client);

echo $response;
}

public function checkEmailAvailibility(){

$api_url = site_url()."data/checkEmailAvailibility";
$form_data = array(
 'email'  => $this->input->post('email'),
);
$client = curl_init($api_url);

curl_setopt($client, CURLOPT_POST, true);

curl_setopt($client, CURLOPT_POSTFIELDS, $form_data);

curl_setopt($client, CURLOPT_RETURNTRANSFER, true);

$response = curl_exec($client);

curl_close($client);

echo $response;
}


/* ***************************************** Home Pages APIs *******************************************/
    
    public function getHomeData(){
        $api_url = site_url()."app/getHomeData";

        $client = curl_init($api_url);
        $form_data=array(
            'user_id'=>$this->input->post('user_id'),
            'device_id' => $this->input->post('device_id')
            );
        curl_setopt($client, CURLOPT_POST, true);
        
        curl_setopt($client, CURLOPT_POSTFIELDS, $form_data);
        
        curl_setopt($client, CURLOPT_RETURNTRANSFER, true);
        
        $response = curl_exec($client);
        
        curl_close($client);
        
        echo $response; 
    }
    public function getAllCategory(){
        
        $api_url = site_url()."app/getAllCategory";

        $client = curl_init($api_url);
        
        curl_setopt($client, CURLOPT_POST, true);
        
        curl_setopt($client, CURLOPT_POSTFIELDS, false);
        
        curl_setopt($client, CURLOPT_RETURNTRANSFER, true);
        
        $response = curl_exec($client);
        
        curl_close($client);
        
        echo $response;
    } 
    
    
    public function getAllProduct(){

    $api_url = site_url()."app/getAllProduct";

    $client = curl_init($api_url);
    
    curl_setopt($client, CURLOPT_POST, true);
    
    curl_setopt($client, CURLOPT_POSTFIELDS, false);
    
    curl_setopt($client, CURLOPT_RETURNTRANSFER, true);
    
    $response = curl_exec($client);
    
    curl_close($client);
    
    echo $response;
    }
    
    public function getAllCategoryProduct(){

    $api_url = site_url()."app/getAllCategoryProduct";
    $client = curl_init($api_url);
    $form_data=array(
        'category_id'=>$this->input->post('category_id'),
        'user_id'=>$this->input->post('user_id'),
        'page'=>$this->input->post('page'),
        'device_id' => $this->input->post('device_id')
        );
    $client = curl_init($api_url);
    
    curl_setopt($client, CURLOPT_POST, true);
    
    curl_setopt($client, CURLOPT_POSTFIELDS, $form_data);
    
    curl_setopt($client, CURLOPT_RETURNTRANSFER, true);
    
    $response = curl_exec($client);
    
    curl_close($client);
    
    echo $response;
    }
    
    
    public function getPromotionalCategoryProduct()
    {

    $api_url = site_url()."app/getPromotionalCategoryProduct";
    $client = curl_init($api_url);
    $form_data=array(
        'category_id'=>$this->input->post('category_id'),
        'user_id'=>$this->input->post('user_id'),
        'page'=>$this->input->post('page'),
        'device_id' => $this->input->post('device_id')
        );
    $client = curl_init($api_url);
    
    curl_setopt($client, CURLOPT_POST, true);
    
    curl_setopt($client, CURLOPT_POSTFIELDS, $form_data);
    
    curl_setopt($client, CURLOPT_RETURNTRANSFER, true);
    
    $response = curl_exec($client);
    
    curl_close($client);
    
    echo $response;
    }
    
    public function getAllSubCategory($id){

    $api_url = site_url()."app/getAllSubCategory/$id";

    $client = curl_init($api_url);
    
    curl_setopt($client, CURLOPT_POST, true);
    
    curl_setopt($client, CURLOPT_POSTFIELDS, false);
    
    curl_setopt($client, CURLOPT_RETURNTRANSFER, true);
    
    $response = curl_exec($client);
    
    curl_close($client);
    
    echo $response;
    }
    

    public function verifyMycart()
    {   $api_url = site_url()."app/verifyMycart";
        $requiredFields = array("user_id");
        $form_data = array(
           'user_id'   => $_REQUEST['user_id']
        );
            $fields = array_diff_key(array_flip($requiredFields), $_REQUEST);
            if(!empty($fields))
            {
                $response["error"] = false;
                $missing_fields = implode(",", array_keys($fields));
                $response["missing_fields"] = $missing_fields;
                $response["message"] = "Some Fields are missing";
            }
            else
            {
               $client = curl_init($api_url);    
                curl_setopt($client, CURLOPT_POST, true);            
                curl_setopt($client, CURLOPT_POSTFIELDS, $form_data);            
                curl_setopt($client, CURLOPT_RETURNTRANSFER, true);            
                $response = curl_exec($client);            
                curl_close($client);            
                echo $response;
            }            
        
    }

    
    public function getAllOffer()
    {

    $api_url = site_url()."app/getAllOffer";
    $form_data=array(
        'user_id'=>$this->input->post('user_id'),
        'page'=>$this->input->post('page'),
        'device_id' => $this->input->post('device_id')
        );
    $client = curl_init($api_url);
    
    curl_setopt($client, CURLOPT_POST, true);
    
    curl_setopt($client, CURLOPT_POSTFIELDS,$form_data);
    
    curl_setopt($client, CURLOPT_RETURNTRANSFER, true);
    
    $response = curl_exec($client);
    
    curl_close($client);
    
    echo $response;
    }

    
    public function myBooking()
    {
        $api_url = site_url()."app/myBooking";
        $form_data = array(
           'user_id'   => $this->input->post('user_id'),
           'flag'  => $this->input->post('flag'),
           'device_id' => $this->input->post('device_id'),
           'page' => $this->input->post('page')
        );
        $client = curl_init($api_url);
    
        curl_setopt($client, CURLOPT_POST, true);
    
        curl_setopt($client, CURLOPT_POSTFIELDS, $form_data);
    
        curl_setopt($client, CURLOPT_RETURNTRANSFER, true);
    
        $response = curl_exec($client);
    
        curl_close($client);
    
        echo $response;
    }
    
    
    public function getBookingDetails()
    {
        $api_url = site_url()."app/getBookingDetails";
        $form_data = array(
           'user_id'   => $this->input->post('user_id'),
           'order_id'   => $this->input->post('order_id'),
           'device_id' => $this->input->post('device_id')
        );
        $client = curl_init($api_url);
    
        curl_setopt($client, CURLOPT_POST, true);
    
        curl_setopt($client, CURLOPT_POSTFIELDS, $form_data);
    
        curl_setopt($client, CURLOPT_RETURNTRANSFER, true);
    
        $response = curl_exec($client);
    
        curl_close($client);
    
        echo $response;
    }
    

    
    public function addMyWishList()
    {
        $api_url = site_url()."app/addMyWishList";
        $form_data = array(
            'user_id'   => $this->input->post('user_id'),
            'product_type'   => $this->input->post('product_type'),
            'product_id'  => $this->input->post('product_id'),
            'wishlist_id'=>$this->input->post('wishlist_id'),
            'device_id' => $this->input->post('device_id')
        );
        $client = curl_init($api_url);
    
        curl_setopt($client, CURLOPT_POST, true);
    
        curl_setopt($client, CURLOPT_POSTFIELDS, $form_data);
    
        curl_setopt($client, CURLOPT_RETURNTRANSFER, true);
    
        $response = curl_exec($client);
    
        curl_close($client);
    
        echo $response;
    }
    
    public function myWishList(){
        $api_url = site_url()."app/myWishList";
        $form_data = array(
            'user_id'   => $this->input->post('user_id'),
            'page'   => $this->input->post('page'),
            'device_id' => $this->input->post('device_id')
        );
        $client = curl_init($api_url);
    
        curl_setopt($client, CURLOPT_POST, true);
    
        curl_setopt($client, CURLOPT_POSTFIELDS, $form_data);
    
        curl_setopt($client, CURLOPT_RETURNTRANSFER, true);
    
        $response = curl_exec($client);
    
        curl_close($client);
    
        echo $response;
    }

    public function deleteWishList(){
        $api_url = site_url()."app/deleteWishList";
        $form_data = array(
            'user_id'   => $this->input->post('user_id'),
            'product_id'   => $this->input->post('product_id'),
            'product_type' => $this->input->post('product_type'),
            'device_id' => $this->input->post('device_id')
        );
        $client = curl_init($api_url);
    
        curl_setopt($client, CURLOPT_POST, true);
    
        curl_setopt($client, CURLOPT_POSTFIELDS, $form_data);
    
        curl_setopt($client, CURLOPT_RETURNTRANSFER, true);
    
        $response = curl_exec($client);
    
        curl_close($client);
    
        echo $response;
    }


    public function getProductById($id){

        $api_url = site_url()."app/getProductById/$id";
    
        $client = curl_init($api_url);
        
        curl_setopt($client, CURLOPT_POST, true);
        
        curl_setopt($client, CURLOPT_POSTFIELDS, false);
        
        curl_setopt($client, CURLOPT_RETURNTRANSFER, true);
        
        $response = curl_exec($client);
        
        curl_close($client);
        
        echo $response;
    }
          
    public function AddToCart(){  
        $api_url = site_url()."app/AddToCart";
    
        $client = curl_init($api_url);
        $form_data = array(
            'product_id'   => $this->input->post('product_id'),
            'product_type'   => $this->input->post('product_type'),
            'flag'   => $this->input->post('flag'),
            'product_quantity'   => $this->input->post('product_quantity'),
            'user_id'   => $this->input->post('user_id'),
            'device_id'  => $this->input->post('device_id'),

        );
        curl_setopt($client, CURLOPT_POST, true);
        
        curl_setopt($client, CURLOPT_POSTFIELDS, $form_data);
        
        curl_setopt($client, CURLOPT_RETURNTRANSFER, true);
        
        $response = curl_exec($client);
        
        curl_close($client);
        
        echo $response;     
            
    } 
    
    public function myCart(){  
        $api_url = site_url()."app/myCart";
    
        $client = curl_init($api_url);
        $form_data = array(
            'user_id'   => $this->input->post('user_id'),
            'device_id' => $this->input->post('device_id')
        );
        curl_setopt($client, CURLOPT_POST, true);
        
        curl_setopt($client, CURLOPT_POSTFIELDS, $form_data);
        
        curl_setopt($client, CURLOPT_RETURNTRANSFER, true);
        
        $response = curl_exec($client);
        
        curl_close($client);
        
        echo $response;     
            
    } 
    public function getCartQty(){  
        $api_url = site_url()."app/getCartQty";
    
        $client = curl_init($api_url);
        $form_data = array(
            'user_id'   => $this->input->post('user_id'),
            'device_id' => $this->input->post('device_id')
        );
        curl_setopt($client, CURLOPT_POST, true);
        
        curl_setopt($client, CURLOPT_POSTFIELDS, $form_data);
        
        curl_setopt($client, CURLOPT_RETURNTRANSFER, true);
        
        $response = curl_exec($client);
        
        curl_close($client);
        
        echo $response;     
            
    } 

    public function ManageAddToCart(){  
        $api_url = site_url()."app/ManageAddToCart";
    
        $client = curl_init($api_url);
        $form_data = array(
            'product_id'   => $this->input->post('product_id'),
            'product_quantity'   => $this->input->post('product_quantity'),
            'user_id'   => $this->input->post('user_id'),
            'device_id' => $this->input->post('device_id')

        );
        curl_setopt($client, CURLOPT_POST, true);
        
        curl_setopt($client, CURLOPT_POSTFIELDS, $form_data);
        
        curl_setopt($client, CURLOPT_RETURNTRANSFER, true);
        
        $response = curl_exec($client);
        
        curl_close($client);
        
        echo $response;     
            
    } 

    public function AddToWishList(){  
        $api_url = site_url()."app/AddToWishList";
    
        $client = curl_init($api_url);
        $form_data = array(
            'product_id'   => $this->input->post('product_id'),
            'user_id'   => $this->input->post('user_id'),
            'device_id' => $this->input->post('device_id')

        );
        curl_setopt($client, CURLOPT_POST, true);
        
        curl_setopt($client, CURLOPT_POSTFIELDS, $form_data);
        
        curl_setopt($client, CURLOPT_RETURNTRANSFER, true);
        
        $response = curl_exec($client);
        
        curl_close($client);
        
        echo $response;     
            
    } 

    public function DeleteCartProduct(){  
        $api_url = site_url()."app/DeleteCartProduct";
    
        $client = curl_init($api_url);
        $form_data = array(
            'cart_id'   => $this->input->post('cart_id'),
            'user_id'   => $this->input->post('user_id'),
            'device_id' => $this->input->post('device_id')
        );
        curl_setopt($client, CURLOPT_POST, true);
        
        curl_setopt($client, CURLOPT_POSTFIELDS, $form_data);
        
        curl_setopt($client, CURLOPT_RETURNTRANSFER, true);
        
        $response = curl_exec($client);
        
        curl_close($client);
        
        echo $response;     
            
    }
    
    public function addressBook(){
        $api_url = site_url()."app/addressBook";
    
        $client = curl_init($api_url);
        $form_data = array(
            'name'   => $this->input->post('name'),
            'address'   => $this->input->post('address'),
            'pincode'   => $this->input->post('pincode'),
            'mobile'   => $this->input->post('mobile'),
            'user_id'   => $this->input->post('user_id'),
            'device_id' => $this->input->post('device_id'),
            'address_id'   => $this->input->post('address_id'),
            'landmark'   => $this->input->post('landmark')
        );
        curl_setopt($client, CURLOPT_POST, true);
        
        curl_setopt($client, CURLOPT_POSTFIELDS, $form_data);
        
        curl_setopt($client, CURLOPT_RETURNTRANSFER, true);
        
        $response = curl_exec($client);
        
        curl_close($client);
        
        echo $response;     
           
    }
    
    public function getAddressBook(){
        $api_url = site_url()."app/getAddressBook";
    
        $client = curl_init($api_url);
        $form_data = array(
           'user_id'   => $this->input->post('user_id'),
           'device_id' => $this->input->post('device_id')
        );
        curl_setopt($client, CURLOPT_POST, true);
        
        curl_setopt($client, CURLOPT_POSTFIELDS, $form_data);
        
        curl_setopt($client, CURLOPT_RETURNTRANSFER, true);
        
        $response = curl_exec($client);
        
        curl_close($client);
        
        echo $response;     
           
    }
    public function deleteAddressBook(){
        $api_url = site_url()."app/deleteAddressBook";
    
        $client = curl_init($api_url);
        $form_data = array(
           'user_id'   => $this->input->post('user_id'),
           'address_id'   => $this->input->post('address_id'),
           'device_id' => $this->input->post('device_id')
        );
        curl_setopt($client, CURLOPT_POST, true);
        
        curl_setopt($client, CURLOPT_POSTFIELDS, $form_data);
        
        curl_setopt($client, CURLOPT_RETURNTRANSFER, true);
        
        $response = curl_exec($client);
        
        curl_close($client);
        
        echo $response; 
    }
    
    public function getDefaultAddress(){
        $api_url = site_url()."app/getDefaultAddress";
        $form_data = array(
           'user_id'   => $this->input->post('user_id'),
           'device_id' => $this->input->post('device_id')
        );
        $client = curl_init($api_url);
    
        curl_setopt($client, CURLOPT_POST, true);
    
        curl_setopt($client, CURLOPT_POSTFIELDS, $form_data);
    
        curl_setopt($client, CURLOPT_RETURNTRANSFER, true);
    
        $response = curl_exec($client);
    
        curl_close($client);
    
        echo $response;
    }
    
    public function getCountry(){
        $api_url = site_url()."app/getCountry";
       
        $client = curl_init($api_url);
    
        curl_setopt($client, CURLOPT_POST, true);
    
        curl_setopt($client, CURLOPT_POSTFIELDS, false);
    
        curl_setopt($client, CURLOPT_RETURNTRANSFER, true);
    
        $response = curl_exec($client);
    
        curl_close($client);
    
        echo $response;
    }
    
     public function getMessages(){
        $api_url = site_url()."app/getMessages";
       
        $client = curl_init($api_url);
    
        curl_setopt($client, CURLOPT_POST, true);
    
        curl_setopt($client, CURLOPT_POSTFIELDS, false);
    
        curl_setopt($client, CURLOPT_RETURNTRANSFER, true);
    
        $response = curl_exec($client);
    
        curl_close($client);
    
        echo $response;
    }
    
    public function getBanners()
    {
        $api_url = site_url()."app/getBanners";       
        $client = curl_init($api_url);    
        curl_setopt($client, CURLOPT_POST, true);    
        curl_setopt($client, CURLOPT_POSTFIELDS, false);    
        curl_setopt($client, CURLOPT_RETURNTRANSFER, true);    
        $response = curl_exec($client);    
        curl_close($client);    
        echo $response;        
    }

     
    public function setDefaultAddress()
    {
        $api_url = site_url()."app/setDefaultAddress";
        $form_data = array(
           'user_id'   => $this->input->post('user_id'),
           'address_id'   => $this->input->post('address_id'),
           'device_id' => $this->input->post('device_id')
        );
        $client = curl_init($api_url);    
        curl_setopt($client, CURLOPT_POST, true);    
        curl_setopt($client, CURLOPT_POSTFIELDS, $form_data);    
        curl_setopt($client, CURLOPT_RETURNTRANSFER, true);    
        $response = curl_exec($client);    
        curl_close($client);    
        echo $response;
    }
    
    
     public function PlaceOrder(){
        $api_url = site_url()."app/PlaceOrder";
        $form_data = array(
           'user_id'   => $this->input->post('user_id'),
           'device_id' => $this->input->post('device_id'),
           'delivery_type' => $this->input->post('delivery_type'),
           'transection_id'=>$this->input->post('transection_id'),
           'payment_type'=>$this->input->post('payment_type'),
           'transection_amount'=>$this->input->post('transection_amount'),
           'transection_message'=>$this->input->post('transection_message'),
           'transection_status'=>$this->input->post('transection_status'),
           'address_id'   => $this->input->post('address_id'),
           'address'=>$this->input->post('address'),
           'name'=>$this->input->post('name'),
           'email'=>$this->input->post('email'),
           'latitude'=>$this->input->post('latitude'),
           'longitude'=>$this->input->post('longitude'),
           'note'=>$this->input->post('note'),
           'coupon_id'=>$this->input->post('coupon_id'),
           'referal_applied'=>$this->input->post('referal_applied'),
        );
        $client = curl_init($api_url);
    
        curl_setopt($client, CURLOPT_POST, true);
    
        curl_setopt($client, CURLOPT_POSTFIELDS, $form_data);
    
        curl_setopt($client, CURLOPT_RETURNTRANSFER, true);
    
        $response = curl_exec($client);
    
        curl_close($client);
    
        echo $response;
    }
    
    public function updateProfile(){
        $api_url = site_url()."app/updateProfile";
        $form_data = array(
           'user_id'   => $this->input->post('user_id'),
           'name'=>$this->input->post('name'),
           'mobile'=>$this->input->post('mobile'),
           'nationality'=>$this->input->post('nationality'),
           'device_id' => $this->input->post('device_id')
        );
        $client = curl_init($api_url);
    
        curl_setopt($client, CURLOPT_POST, true);
    
        curl_setopt($client, CURLOPT_POSTFIELDS, $form_data);
    
        curl_setopt($client, CURLOPT_RETURNTRANSFER, true);
    
        $response = curl_exec($client);
    
        curl_close($client);
    
        echo $response;
    }
    
    public function changePassword(){
        $api_url = site_url()."app/changePassword";
        $form_data = array(
           'user_id'   => $this->input->post('user_id'),
           'current_password'=>$this->input->post('current_password'),
           'new_password'=>$this->input->post('new_password'),
           'confirm_password'=>$this->input->post('confirm_password'),
           'device_id' => $this->input->post('device_id')
        );
        $client = curl_init($api_url);
    
        curl_setopt($client, CURLOPT_POST, true);
    
        curl_setopt($client, CURLOPT_POSTFIELDS, $form_data);
    
        curl_setopt($client, CURLOPT_RETURNTRANSFER, true);
    
        $response = curl_exec($client);
    
        curl_close($client);
    
        echo $response;
    
    }
    
   public function search(){
       $api_url = site_url()."app/search";
        $form_data = array(
           'user_id'   => $this->input->post('user_id'),
           'page'   => $this->input->post('page'),
           'keywords'=>$this->input->post('keywords'),
           'device_id' => $this->input->post('device_id')
        );
        $client = curl_init($api_url);
    
        curl_setopt($client, CURLOPT_POST, true);
    
        curl_setopt($client, CURLOPT_POSTFIELDS, $form_data);
    
        curl_setopt($client, CURLOPT_RETURNTRANSFER, true);
    
        $response = curl_exec($client);
    
        curl_close($client);
    
        echo $response;
   }
   
   public function getCoupons(){
        $api_url = site_url()."app/getCoupons";
        
        $client = curl_init($api_url);
    
        curl_setopt($client, CURLOPT_POST, true);
    
        curl_setopt($client, CURLOPT_POSTFIELDS, false);
    
        curl_setopt($client, CURLOPT_RETURNTRANSFER, true);
    
        $response = curl_exec($client);
    
        curl_close($client);
    
        echo $response;
   }
   
   public function verifyCoupons(){
        $api_url = site_url()."app/verifyCoupons";
         $form_data = array(
           'user_id'   => $this->input->post('user_id'),
           'coupon_id'=>$this->input->post('coupon_id'),
           'amount'=>$this->input->post('amount'),
           'device_id' => $this->input->post('device_id')
        );
        $client = curl_init($api_url);
    
        curl_setopt($client, CURLOPT_POST, true);
    
        curl_setopt($client, CURLOPT_POSTFIELDS, $form_data);
    
        curl_setopt($client, CURLOPT_RETURNTRANSFER, true);
    
        $response = curl_exec($client);
    
        curl_close($client);
    
        echo $response;
   }
   
       public function SetNotificationKeys()
       {
        $api_url = site_url()."app/SetNotificationKeys";
        $form_data = array(
           'user_id'   => $this->input->post('user_id'),
           'pending'   => $this->input->post('pending'),
           'processing'=>$this->input->post('processing'),
           'delivered'=>$this->input->post('delivered'),
           'cancelled'=>$this->input->post('cancelled'),
           'device_id' => $this->input->post('device_id')
        );
        $client = curl_init($api_url);
    
        curl_setopt($client, CURLOPT_POST, true);
    
        curl_setopt($client, CURLOPT_POSTFIELDS, $form_data);
    
        curl_setopt($client, CURLOPT_RETURNTRANSFER, true);
    
        $response = curl_exec($client);
    
        curl_close($client);
    
        echo $response;
    }
    
    public function GetNotificationKeys()
    {
        $api_url = site_url()."app/GetNotificationKeys";
        $form_data = array(
           'user_id'   => $this->input->post('user_id'),
           'device_id' => $this->input->post('device_id')
        );
        
        $client = curl_init($api_url);
    
        curl_setopt($client, CURLOPT_POST, true);
    
        curl_setopt($client, CURLOPT_POSTFIELDS, $form_data);
    
        curl_setopt($client, CURLOPT_RETURNTRANSFER, true);
    
        $response = curl_exec($client);
    
        curl_close($client);
    
        echo $response;
    }
    
    public function getSimilarProducts()
    {
        $api_url = site_url()."app/getSimilarProducts";
        $form_data = array(
           'user_id'   => $this->input->post('user_id'),
           'product_id'   => $this->input->post('product_id'),
           'category_id'   => $this->input->post('category_id'),
           'device_id' => $this->input->post('device_id')
        );
        $client = curl_init($api_url);
    
        curl_setopt($client, CURLOPT_POST, true);
    
        curl_setopt($client, CURLOPT_POSTFIELDS, $form_data);
    
        curl_setopt($client, CURLOPT_RETURNTRANSFER, true);
    
        $response = curl_exec($client);
    
        curl_close($client);
    
        echo $response;
    }
    
    public function SetFcmToken()
    {
        $api_url = site_url()."app/SetFcmToken";
        $form_data = array(
           'user_id'   => $this->input->post('user_id'),
           'fcm_token'   => $this->input->post('fcm_token'),
           'device_id' => $this->input->post('device_id')
        );
        $client = curl_init($api_url);
    
        curl_setopt($client, CURLOPT_POST, true);
    
        curl_setopt($client, CURLOPT_POSTFIELDS, $form_data);
    
        curl_setopt($client, CURLOPT_RETURNTRANSFER, true);
    
        $response = curl_exec($client);
    
        curl_close($client);
    
        echo $response;
    }
}

