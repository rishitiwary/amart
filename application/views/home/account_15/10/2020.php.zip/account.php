<div class="container">
<!--start .my-account -->
<div class="my-account-page">

<div class="left-sidebar">
    <ul>
        <li class="active"><a href="<?= base_url('dashboard') ?>">My Orders</a></li>
        <li><a href="<?= base_url('dashboard/address') ?>">Address</a></li>
        <li><a href="<?= base_url('dashboard/favourite') ?>">Favourite</a></li>
        <li><a href="<?= base_url('dashboard/password') ?>">Change Password</a></li>
        <li><a href="<?= base_url('dashboard/profile') ?>">Personal Details</a></li>
    </ul>
</div>

<div class="right-bx">
    <div class="bx-header">
        <label>MY ORDERS</label>        
        <div class="right-select">
            <span>Sort by :</span>
             <div class="srt-by">
            <select class="dropdown" id="orderData">            
            <option value="all">All</option>
            <option value="com">Complete Order</option>
            <option value="can">Cancelled Order</option>
        </select> 
         </div>       
        </div>
    </div>
<div class="bottom-box">
<div class="table-responsive">
  <div class="all box">
    <table class="table">
      <thead>
        <tr>
          <th scope="col">Order Id</th>
          <th scope="col">Total</th>
          <th scope="col">Status</th>
          <th scope="col">Date</th>
          <th scope="col">Action</th>              
        </tr>
      </thead>
      <tbody>
        <?php foreach ($all as $key => $acc): ?>
          <tr>
            <th scope="row"><?=$acc->order_id?></th>
            <td>AED <?=number_format(@$acc->transection_amount, 2)?></td>
            <td>
              <?php 
              if ($acc->status == "3") { echo 'Cancelled';
              } else if ($acc->status == "1") {
                echo 'Delivered';
              }else {
                echo 'Pending';
              } ?>            
          </td>
            <td><?= date('d-m-Y', strtotime(@$acc->booking_date))?></td>
            <td>
              <a href="<?=base_url()?>dashboard/orderDetails/<?=$acc->order_id?>" class="btn btn-primary" target="_blank" data-toggle="tooltip" title="View Details"><i class="fa fa-eye" aria-hidden="true"></i> 
              </a>
            </td>
          </tr>
        <?php endforeach ?>
        <?php if(count($all)=='0') {?>
        <tr>
          <td colspan="5"> No Orders Found</td>
        </tr>
      <?php } ?>
      </tbody>
    </table>     
    </div>
    <div class="com box">
      <table class="table">
      <thead>
        <tr>
          <th scope="col">Order Id</th>
          <th scope="col">Total</th>
          <th scope="col">Status</th>
          <th scope="col">Date</th>
          <th scope="col">Action</th>              
        </tr>
      </thead>
      <tbody>
        <?php foreach ($normal as $key => $acc): ?>
          <tr>
            <th scope="row"><?=$acc->order_id?></th>
            <td>AED <?=number_format(@$acc->transection_amount, 2)?></td>
            <td>
              <?php 
              if ($acc->status == "3") { echo 'Cancelled';
              } else if ($acc->status == "1") {
                echo 'Delivered';
              }else {
                echo 'Pending';
              } ?>            
          </td>
            <td><?= date('d-m-Y', strtotime(@$acc->booking_date))?></td>
            <td>
              <a href="<?=base_url()?>dashboard/orderDetails/<?=$acc->order_id?>" class="btn btn-primary" data-toggle="tooltip" title="View Details"><i class="fa fa-eye" aria-hidden="true"></i> 
              </a>
            </td>
          </tr>
        <?php endforeach ?>
        <?php if(count($normal)=='0') {?>
        <tr>
          <td colspan="5"> No Orders Found</td>
        </tr>
      <?php } ?>
      </tbody>
    </table>  
    </div>
    <div class="can box">
      <table class="table">
      <thead>
        <tr>
          <th scope="col">Order Id</th>
          <th scope="col">Total</th>
          <th scope="col">Status</th>
          <th scope="col">Date</th>
          <th scope="col">Action</th>              
        </tr>
      </thead>
      <tbody>
        <?php foreach ($cancelled as $key => $acc): ?>
          <tr>
            <th scope="row"><?=$acc->order_id?></th>
            <td>AED <?=number_format(@$acc->transection_amount, 2)?></td>
            <td>
              <?php 
              if ($acc->status == "3") { echo 'Cancelled';
              } else if ($acc->status == "1") {
                echo 'Delivered';
              }else {
                echo 'Pending';
              } ?>            
          </td>
            <td><?= date('d-m-Y', strtotime(@$acc->booking_date))?></td>
            <td>
              <a href="<?=base_url()?>dashboard/orderDetails/<?=$acc->order_id?>" class="btn btn-primary" data-toggle="tooltip" title="View Details"><i class="fa fa-eye" aria-hidden="true"></i> 
              </a>
            </td>
          </tr>
        <?php endforeach ?>
        <?php if(count($cancelled)=='0') {?>
        <tr>
          <td colspan="5"> No Orders Found</td>
        </tr>
      <?php } ?>
      </tbody>
    </table>        
    </div>

        
      </div>
 
    </div>

</div>

</div>
<!--end .my-account -->
</div>